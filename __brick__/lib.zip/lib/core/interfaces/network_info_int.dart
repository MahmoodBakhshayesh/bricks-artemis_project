abstract class NetworkInfoInterface {
  Future<bool> get isConnected;
}
