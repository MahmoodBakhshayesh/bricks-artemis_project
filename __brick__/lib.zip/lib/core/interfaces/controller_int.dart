import 'dart:developer';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'shared_preferences_int.dart';
import '../../../core/navigation/navigation_service.dart';
import '../../initialize.dart';

abstract class ControllerInterface {
  late NavigationServiceInterface nav;
  late SharedPreferencesInterface prefs;
  late WidgetRef ref;
  bool initialized =false;
  MainController() {
    nav = getIt<NavigationService>();
    sharedPref = GetIt.instance<SharedPreferencesInterface>();
    ref = getIt<WidgetRef>();

    if(!initialized) {
      onCreate();
    }
  }


  void onInit() {
    log('$runtimeType Init');
  }

  void onCreate() {
    log('$runtimeType Create');
    initialized =true;
  }
}