class TableNames {
  TableNames._();


  static const String usersTable = "UsersTable";
  static const String logoTable = "LogoTable";
}