import 'package:s/core/interfaces/response_int.dart';

class ResponseImplementation extends ResponseInterface {
  ResponseImplementation({required super.statusCode, required super.message, required super.body});

  factory ResponseImplementation.fromJson(Map<String, dynamic> json) => ResponseImplementation(
        statusCode: json['Status'],
        message: json['Message'],
        body: json['Body'],
      );
}
