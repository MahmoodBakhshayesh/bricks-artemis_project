import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'route_names.dart';
import 'router_notifier.dart';

final rootRouterKey = GlobalKey<NavigatorState>(debugLabel: 'routerKey');

/// This simple provider caches our GoRouter.
// final routerProvider = Provider.autoDispose<GoRouter>((ref) {
//   final notifier = ref.watch(routerNotifierProvider.notifier);
//
//   return GoRouter(
//     navigatorKey: rootRouterKey,
//     refreshListenable: notifier,
//     observers:  [BotToastNavigatorObserver()],
//     debugLogDiagnostics: false,
//     initialLocation: RouteNames.login.path,
//     routes: notifier.routes,
//     redirect: notifier.redirect,
//   );
// });
final router =  GoRouter(
    navigatorKey: rootRouterKey,
    observers:  [BotToastNavigatorObserver()],
    debugLogDiagnostics: false,
    initialLocation: RouteNames.login.path,
    routes:routes,
  );

List<GoRoute> get routes => [
    MyRoute(
        name: RouteNames.login.name,
        path: RouteNames.login.path,
        pageBuilder: (context, state) {
            if(BasicClass.deviceType.isPhone)  return NoTransitionPage<void>(key: state.pageKey, child: const LoginViewPhone());
            if(BasicClass.deviceType.isTablet)  return NoTransitionPage<void>(key: state.pageKey, child: const LoginViewTablet());
            return NoTransitionPage<void>(key: state.pageKey, child: const LoginView());
        },
    ),
    MyRoute(
        name: RouteNames.home.name,
        path: RouteNames.home.path,
        pageBuilder: (context, state) {
            if(BasicClass.deviceType.isPhone)  return NoTransitionPage<void>(key: state.pageKey, child: const HomeViewPhone());
            if(BasicClass.deviceType.isTablet)  return NoTransitionPage<void>(key: state.pageKey, child: const HomeViewTablet());
            return NoTransitionPage<void>(key: state.pageKey, child: const HomeView());
        },
    ),
];