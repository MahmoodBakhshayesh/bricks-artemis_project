import 'package:flutter/foundation.dart';
import 'package:s/core/interface_implementations/parse_exception.dart';
import 'package:s/core/interface_implementations/response.dart';
import 'package:s/core/interfaces/parser_int.dart';

import '../interfaces/exception_int.dart';

class Parser {
  Parser._();

  static Future<R> parse<M, R>(
    ComputeCallback<M, R> callback,
    M toBeParsed, {
    String? debugLabel,
    List<String> neededKeys = const [],
    String startingErrorMessage = '',
  }) async {
    try {
      final R generatedClass = await compute(callback, toBeParsed);
      return generatedClass;
    } catch (e, trace) {
      String? jsonErrorMsg;
      if (neededKeys.isNotEmpty && toBeParsed is ResponseImplementation && toBeParsed.body is Map<String, dynamic>) {
        List<String> availableKeys = (toBeParsed.body as Map<String, dynamic>).keys.toList();
        List<String> missingKeys = neededKeys.where((element) => !availableKeys.contains(element)).toList();
        jsonErrorMsg = '${startingErrorMessage}Missing Parameters:\n ${missingKeys.join('\n')}';
      }

      AppException parseException = ParseException(message: jsonErrorMsg ?? e.toString(), trace: trace);
      throw parseException;
    }
  }
}
