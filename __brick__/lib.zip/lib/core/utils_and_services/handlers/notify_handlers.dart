abstract class NotifyHandlers {

  static void changePassengers(List<Object?>? arguments) {
  }

  static void changeFlights(List<Object?>? arguments) {

  }

}