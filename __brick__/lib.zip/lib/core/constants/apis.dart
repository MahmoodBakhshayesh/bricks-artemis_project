class Apis {
  Apis._();

  static const String baseUrl = "";
  static const String serverSelect = "https://databridge-dcs7.fdcs.ir/dcs";
  static const String logoUrl = "https://imagedcs.fdcs.ir/api/airlineimage/";
}