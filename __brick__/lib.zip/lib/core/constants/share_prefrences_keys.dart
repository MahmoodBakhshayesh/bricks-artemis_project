class SpKeys {
  SpKeys._();

  static const String username = "Username";
  static const String password = "Password";
  static const String airline = "Airline";
  static const String cuppsAddress = "CuppsAddress";
  static const String server = "SelectedServer";
}
