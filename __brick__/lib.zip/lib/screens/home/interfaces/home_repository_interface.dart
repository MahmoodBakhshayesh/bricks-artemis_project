import 'package:dartz/dartz.dart';
import '../../../core/abstracts/failures_int.dart';

abstract class HomeRepositoryInterface {
  // Future<Either<Failure, HomeResponse>> home(HomeRequest request);
}