import '../../core/abstracts/controller_int.dart';
import '../../core/util/app_data.dart';
import '../../core/util/handlers/failure_handler.dart';

import 'home_state.dart';

class HomeController extends ControllerInterface {
  late HomeState homeState = ref.read(homeProvider);

  void logout() {}
  // UseCase UseCase = UseCase(repository: Repository());

}
